import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import NotFound from './components/NotFound';
import Counter from './components/Counter';
import room1 from './assets/images/room1.png';
import './App.css';

const App = () => {
  const [activeLink, setActiveLink] = useState(null);

  const handleLinkClick = (link) => {
    setActiveLink(link);
  };

  return (
    <Router>
      <div className="app-container">
        <aside className="sidebar">
          <nav className="nav-bar">
            <div className="profile-container">
              <img src="https://th.bing.com/th/id/R.cb331d845f324231c4b15f1c5f37d6f2?rik=sflwM%2f72VFjS0A&riu=http%3a%2f%2fclipartmag.com%2fimages%2fheadshot-silhouette-clipart-26.png&ehk=x8ED4eqysH%2fwrymdu8fxbHJD1YqNAUWxcjWVznriB3s%3d&risl=&pid=ImgRaw&r=0" alt="Profile" className="profile-image unknown" />
              <button className="profile-button">Profile</button>
            </div>
            <ul className="nav-links">
              <li className="nav-link">
                <Link to="/" onClick={() => handleLinkClick('home')}>
                  <i className="fas fa-home" /> Home
                </Link>
              </li>
              <li className="nav-link">
                <Link to="/about" onClick={() => handleLinkClick('about')}>
                  <i className="fas fa-info-circle" /> About
                </Link>
              </li>
              <li className="nav-link">
                <Link to="/contact" onClick={() => handleLinkClick('contact')}>
                  <i className="fas fa-envelope" /> Contact
                </Link>
              </li>
              <li className="nav-link">
                <Link to="/counter" onClick={() => handleLinkClick('counter')}>
                  <i className="fas fa-counter" /> Counter
                </Link>
              </li>
            </ul>
          </nav>
          <div className="sidebar-footer">
            <img src={room1} alt="R.A Hotel Services" width="50" height="50" />
            <p>R.A Hotel Services</p>
          </div>
        </aside>
        <main className="content-area">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/counter" element={<Counter />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
};

export default App;