// src/components/Counter.js
import React, { useState } from 'react';

const Counter = () => {
  // Initialize the counter state
  const [count, setCount] = useState(0);

  // Handler to increment the count
  const increment = () => setCount(count + 1);

  // Handler to decrement the count
  const decrement = () => setCount(count - 1);

  // Handler to reset the count
  const reset = () => setCount(0);

  return (
    <div>
      <h1>Counter: {count}</h1>
      <button onClick={increment}>Increment</button>
      <button onClick={decrement}>Decrement</button>
      <button onClick={reset}>Reset</button>
    </div>
  );
};

export default Counter;
