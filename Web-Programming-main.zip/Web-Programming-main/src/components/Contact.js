// src/components/Contact.js
import React from 'react';

const Contact = () => (
  <div>
    <h1>Contact Us</h1>
    <form>
      <label>
        Name:
        <input type="text" />
      </label>
      <br />
      <label>
        Email:
        <input type="email" />
      </label>
      <br />
      <label>
        Message:
        <textarea />
      </label>
      <br />
      <button type="submit">Send</button>
    </form>
  </div>
);

export default Contact;
