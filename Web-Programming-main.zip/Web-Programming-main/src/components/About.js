// src/components/About.js
import React from 'react';

const About = () => (
  <div>
    <h1>About This Application</h1>
    <p>Yes im tired of making it look good due to bugs on my pc not like anyone would see this hehe.</p>
  </div>
);

export default About;
