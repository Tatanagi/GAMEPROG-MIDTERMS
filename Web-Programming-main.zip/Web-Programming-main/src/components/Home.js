import React from 'react';

const Home = () => {
  return (
    <div className="home-container">
      <h1>Welcome to R.A Hotel Services</h1>
      <p>
        Our hotel offers luxurious rooms with modern amenities and exceptional service. Whether you're traveling for business or leisure, we have a room that's perfect for you.
      </p>
      <div className="room-gallery">
        <img src="add image here" alt="Deluxe Room" />
        <img src="add here" alt="Suite Room" />
        <img src="add 3rd here" alt="Family Room" />
      </div>
      <h2>Room Variations</h2>
      <ul>
        <li>
          <h3>Deluxe Room</h3>
          <p>Our Deluxe Room features a king-size bed, flat-screen TV, and modern bathroom.</p>
        </li>
        <li>
          <h3>Suite Room</h3>
          <p>Our Suite Room features a separate living area, king-size bed, and luxurious bathroom.</p>
        </li>
        <li>
          <h3>Family Room</h3>
          <p>Our Family Room features two queen-size beds, flat-screen TV, and modern bathroom.</p>
        </li>
      </ul>
    </div>
  );
};

export default Home;